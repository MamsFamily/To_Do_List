# Replace this with the full code ChatGPT provided earlier.
